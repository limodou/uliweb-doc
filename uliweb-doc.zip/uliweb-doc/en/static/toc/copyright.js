/*!
  * jquery.toc.js - A jQuery plugin that will automatically generate a table of contents. 
  * v0.1.0
  * https://github.com/jgallen23/toc
  * copyright JGA 2012
  * MIT License
  */
