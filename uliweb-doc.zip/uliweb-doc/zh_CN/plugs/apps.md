# Plugs App 清单


## plugs.ui

### plugs.ui.jquery.jqdropdown

用来实现类似于bootstrap dropdown的jquery插件。

* https://github.com/claviska/jquery-dropdown

